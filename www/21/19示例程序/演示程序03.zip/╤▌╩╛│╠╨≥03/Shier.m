function dy=Shier(t,y)
dy = zeros(2,1);    % a column vector
r=1;d=0.5;a=0.1;b=0.02;
%y=diag([r-a*x(2),-d+b*x(1)])*x;
dy(1)=r*y(1)-a*y(1)*y(2);
dy(2)=-d*y(2)+b*y(1)*y(2);