function dx=stiff(t,x)
c=10^6;
dx=[x(1)+2*x(2);-(c+1)*x(1)-(c+2)*x(2)];
