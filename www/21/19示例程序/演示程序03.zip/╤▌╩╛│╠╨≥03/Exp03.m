% ��ǰEuler��
x=1:0.001:10; plot(x,log(x),'r','LineWidth',2); hold on;
h=1; 
x=1:h:10; y(1)=0;
for k=2:length(x)
    y(k)=y(k-1)+h/x(k-1);
end
plot(x,y,'bo-','LineWidth',2)

h=0.5; 
x=1:h:10; y(1)=0;
for k=2:length(x)
    y(k)=y(k-1)+h/x(k-1);
end
plot(x,y,'go-','LineWidth',2)

h=0.25;
x=1:h:10; y(1)=0;
for k=2:length(x)
    y(k)=y(k-1)+h/x(k-1);
end
plot(x,y,'ko-','LineWidth',2)

% �Ľ�Euler��, y1��Euler�������y2Ϊ�Ľ�Euler
% ����ͼ�ֱ���ʾ����1��0.4�Ľ��
clear; close;
h=1;
x=0:h:8;
y=(x+1).^2-exp(x)/2;
y1=1/2; y2=1/2;

n=length(x);
for k=2:n
    y1(k)=y1(k-1)+h*(y1(k-1)-x(k-1)^2+1);
end

for k=2:n
    yy=y2(k-1)+h*(y2(k-1)-x(k-1)^2+1);
    y2(k)=y2(k-1)+h*(y2(k-1)-x(k-1)^2+1+yy-x(k)^2+1)/2;
end

subplot(1,2,1);
plot(x,y,'LineWidth',2); hold on; 
plot(x,y1,'R*','MarkerSize',16,'LineWidth',2); 
plot(x,y2,'Go','MarkerSize',16,'LineWidth',2);

h=0.4;
x=0:h:8;
y=(x+1).^2-exp(x)/2;
y1=1/2; y2=1/2;

n=length(x);
for k=2:n
    y1(k)=y1(k-1)+h*(y1(k-1)-x(k-1)^2+1);
end

for k=2:n
    yy=y2(k-1)+h*(y2(k-1)-x(k-1)^2+1);
    y2(k)=y2(k-1)+h*(y2(k-1)-x(k-1)^2+1+yy-x(k)^2+1)/2;
end

subplot(1,2,2);
plot(x,y,'LineWidth',2); hold on; 
plot(x,y1,'R*','MarkerSize',16,'LineWidth',2); 
plot(x,y2,'Go','MarkerSize',16,'LineWidth',2)

% ʵ��1�����ϼ�˽
clear,
%Set the definied time
ts=0:0.05:.6;

x0=[0 0];
a=20;b=40;c=15;
opt=odeset('RelTol',1e-6,'AbsTol',1e-9);

[t,x]=ode23(@jisi,ts,x0,[],a,b,c);
y1=a*t;

% draw x(t),y(t)
subplot(1,2,1); 
plot(t,x(:,1),'r'),
grid on,hold on;
gtext('x(t)','FontSize',16),
plot(t,x(:,2),'v')
gtext('y(t)','FontSize',16),pause

%draw y(x): the position of tatch jisi
subplot(1,2,2); plot(x(:,1),x(:,2),'r*'),
grid on, hold on,
xlabel('x','FontSize',16),ylabel('y','FontSize',16)
plot(15*ones(length(x),1),y1,'b*')

% ��ʾ׷�ٹ���
close;
plot(x(1,1),x(1,2),'r*'); hold on;
plot(15,y1(1),'bo'); 
axis([0 16 0 12]);  pause
for k=2:length(x)
    plot(x(k,1),x(k,2),'r*');
    plot(15,y1(k),'bo'); 
    plot(x(k-1,1),x(k-1,2),'g*');
    plot(15,y1(k-1),'ko');pause;
end



% ��������һ�����
ts=0:0.05:1.6;
x0=[0 0];
a=35;b=40;c=15;
%opt=odeset('RelTol',1e-6,'AbsTol',1e-9);
[t,x]=ode45(@jisi,ts,x0,[],a,b,c);
%[t,x]=ode45(@jisi,ts,x0,opt,a,b,c);
%exact solution x1=c
y1=a*t;

%output t,x(t),y(t) and draw x(t),y(t)
[t,x,y1]
subplot(1,2,1); plot(t,x),grid,
gtext('x(t)','FontSize',16),
gtext('y(t)','FontSize',16),pause

%draw y(x): the position of tatch jisi
subplot(1,2,2); plot(x(:,1),x(:,2),'r*'),grid
xlabel('x','FontSize',16),ylabel('y','FontSize',16)

% ʵ��2  ����ǿʳ����ʳ��̬��
clear; close;
[t,x]=ode45(@Shier,[0 15],[25 2]);
plot(t,x(:,1),'r'),grid,hold on;
gtext('x(t)','FontSize',16),
plot(t,x(:,2),'g'),
gtext('y(t)','FontSize',16);
pause;
close
axis([min(x(:,1)) max(x(:,1)) min(x(:,2)) max(x(:,2))]); 
hold on
plot(x(1,1),x(1,2),'ro');
for k=2:length(x)  
    plot(x(k,1),x(k,2),'o'); 
    pause; 
end

% ����һ�����ڵ�ƽ��ֵ
s=norm(x(2,:)-x(1,:));
for k=3:length(x)  
    if norm(x(k,:)-x(1,:))<s
        break
    end 
end
trapz(t(1:k),x(1:k,:))/t(k)


% �����˿����ݣ�1790����2000�꣬���ݼ������10��
[3.9 5.3 7.2 9.6 12.9 17.1 23.2 31.4 38.6 50.2 62.9 76.0 
    92.0 106.5 123.2 131.7 150.7 179.3 204.0 226.5 251.4 281.4]

