function dy = fsir(t,y)
b=0.001407
%b=0.0006;
dy = zeros(3,1);    % a column vector
dy(1) = 0.6*y(2);
dy(2) = -0.6*y(2)+b*y(2)*y(3);
dy(3) = -b*y(2)*y(3);